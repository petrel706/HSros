/************************************************************************/
/* 
* @brief 演示运动到指定位置（关节坐标）
*/
/************************************************************************/

#include <iostream>
//#include <windows.h>
#include <unistd.h>
#include <pthread.h>
#include "CommApi.h"
#include "proxy/ProxyMotion.h"

bool connectIPC(Hsc3::Comm::CommApi & cmApi, std::string strIP, uint16_t uPort);
bool disconnectIPC(Hsc3::Comm::CommApi & cmApi);
void loadPosData(GeneralPos & generalPos, double axis0, double axis1, double axis2, double axis3, double axis4, double axis5, bool isJoint);
void waitDone(Hsc3::Proxy::ProxyMotion & pMot);

int main()
{
    GeneralPos targetPos1, targetPos2;
    Hsc3::Comm::CommApi cmApi("./");
    Hsc3::Proxy::ProxyMotion pMot(&cmApi);
    
    /************************************************************************/
    /* 
    *  原点关节坐标：{0,-90, 180, 0, 90, 0} 
    *  指定到达的关节坐标：{11.60971, -90.49248, 182.82715, 6.721339, 93.89419, 0}
    */
    /************************************************************************/
    //记录点位
    
    loadPosData(targetPos1, 11.60971, -90.49248, 182.82715, 6.721339, 93.89419, 0, true);
    loadPosData(targetPos2, 0, -90, 180, 0, 90, 0, true);


    if (connectIPC(cmApi,"10.10.56.214",23234))
    {
        pMot.setOpMode(OP_T1);
        pMot.setWorkFrame(0, FRAME_JOINT);

        //机器人上使能
        pMot.setGpEn(0, true);
        sleep(1);
        
        //先运动到targetPos1
        pMot.moveTo(0, targetPos1, false);
        waitDone(pMot);
        sleep(1);
        std::cout << "关节运动到先运动到targetPos1成功！" << std::endl;


        //再运动到targetPos2
        pMot.moveTo(0, targetPos2, false);
        waitDone(pMot);
        std::cout << "关节运动到先运动到targetPos2成功！" << std::endl;
        sleep(1);
    }
    else
    {
        std::cout<<"连接失败"<<std::endl;
    }

    //机器人下使能
    pMot.setGpEn(0, false);
    //断连
    disconnectIPC(cmApi);

    system("pause");
    return 0;
}

/************************************************************************/
/*            
* @brief 连接IPC
* @param cmApi:通信客户端对象，建议在自定义的函数中如果需要传递客户端对象，都使用引用传递。
* @param strIP:IP，控制器默认IP是"10.10.56.214"
* @param uPort:端口号,固定端口号:23234
*/
/************************************************************************/
bool connectIPC(Hsc3::Comm::CommApi & cmApi, std::string strIP,uint16_t uPort)
{
    //1.设置非自动重连模式,连接前调用。
    cmApi.setAutoConn(false);
    //2.连接
    Hsc3::Comm::HMCErrCode ret = cmApi.connect(strIP,uPort);
    if (ret!=0)
    {
        printf("CommApi::connect() : ret = %lld\n",ret);
    }
    //3.查询是否连接
    if (cmApi.isConnected())
    {
        std::cout<<"连接成功"<<std::endl;
        return true;
    }
    else
    {
        std::cout<<"连接失败"<<std::endl;
        return false;
    }
}

/************************************************************************/
/* 
* @brief 断开与IPC的连接
* @param cmApi:通信客户端对象
*/
/************************************************************************/
bool disconnectIPC(Hsc3::Comm::CommApi & cmApi)
{
    Hsc3::Comm::HMCErrCode ret=cmApi.disconnect();
    sleep(5);
    if (cmApi.isConnected())
    {
        return false;
    }
    else
    {
        return true;
    }
}

/************************************************************************/
/* 
* @brief 装载数据
*/
/************************************************************************/
void loadPosData(GeneralPos & generalPos, double axis0, double axis1, double axis2, double axis3, double axis4, double axis5, bool isJoint)
{
    generalPos.config=1048576;
    generalPos.isJoint=isJoint;
    generalPos.ufNum=-1;
    generalPos.utNum=-1;
    generalPos.vecPos.push_back(axis0);
    generalPos.vecPos.push_back(axis1);
    generalPos.vecPos.push_back(axis2);
    generalPos.vecPos.push_back(axis3);
    generalPos.vecPos.push_back(axis4);
    generalPos.vecPos.push_back(axis5);
    generalPos.vecPos.push_back(0);
    generalPos.vecPos.push_back(0);
    generalPos.vecPos.push_back(0);
}

/************************************************************************/
/* 
* @brief 等待运动停止，只能用于手动模式下运动到点，用于检测是否处于静止或错误状态
* @param pMot:运动功能代理
*/
/************************************************************************/
void waitDone(Hsc3::Comm::CommApi & cmApi)
{
	Sleep(200);
    while(true)
    {
		std::string reStr{};
		HMCErrCode ret = cmApi.execCmd("?group[0].status", reStr, 3);
		if(ret != 0{
			cout << "接口返回错误" << endl;
			break;
		}
		
		// 等于2，相当于运动停止
        if (ret == 0 && reStr == "\"2\"")
        {
            break;
        }
		Sleep(200);
    }
}